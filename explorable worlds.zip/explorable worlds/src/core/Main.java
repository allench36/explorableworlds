package core;

import edu.princeton.cs.algs4.StdDraw;
import tileengine.TERenderer;
import tileengine.TETile;
import tileengine.Tileset;

import java.io.IOException;
import java.nio.file.*;
import java.util.Random;

public class Main {
    // To do: saving/loading, interacting with input strings (Autograder
    // buddy)


    /** Changes
     * A bug was making some floor tiles impassable. Changed the implementation of movement to be
     * less verbose and more cleanly abstracted to prevent bugs and to make implementation of saving
     * and string interaction easier. Character movement is now fully contained in the World
     * class. Render methods ONLY render and nothing else
     *
     * Added quitting
     *
     *
     *
     */

    private static World world;
    private static String seed;
    private static Random random;
    private static TERenderer ter;

    private static Path save = Paths.get("save.txt");

    private static String saveString;

    private static int mouseX = 10000;
    private static int mouseY = 10000;
    private static boolean losOn = true;
    private static String avatarName = "";
    private static int gamestate;
    public static void main(String[] args) {

        renderMainMenu();
        gamestate = 0; // 0 = Main menu screen; 1 = New game screen;
        // 2 = Load game; 3 = Gameplay;
        seed = "";

        try {
            saveString = Files.readAllLines(save).get(0);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // Allows jumps between gamestates
        while (true) {
            while (gamestate == 0) {
                mainMenu();
            }
            while (gamestate == 1) {
                newGame();
            }
            while (gamestate == 2) {
                loadGame();
            }
            while (gamestate == 3) {
                playGame();
            }
        }
    }

    private static void generateWorld() {
        long newSeed = Long.parseLong(seed); // converts seed into a long
        random = new Random(newSeed);
        world = new World(random);
        ter = new TERenderer();
        ter.initialize(world.getWIDTH(), world.getHEIGHT() + 3);
    }

    private static void mainMenu() {
        if (StdDraw.hasNextKeyTyped()) {
            char s = StdDraw.nextKeyTyped();

            if (s == 'n' || s == 'N') {
                saveString = "";
                renderAvatarMenu();
                saveString += "N";
                StdDraw.clear();
                StdDraw.disableDoubleBuffering();
                renderNewGameMenu();
                gamestate = 1;
            } else if (s == 'l' || s == 'L') {
                gamestate = 2;
            } else if (s == 'q' || s == 'Q') {
                quitGame();
            }
        }
    }

    private static void newGame() {
        if (StdDraw.hasNextKeyTyped()) {
            char typed = StdDraw.nextKeyTyped();

            if (typed == 's' || typed == 'S') {
                if (!seed.isEmpty()) {
                    saveString += typed;
                    generateWorld();
                    renderGame((int) StdDraw.mouseX(), (int) StdDraw.mouseY());
                    gamestate = 3;
                }
            } else {
                if (Character.isDigit(typed)) {
                    saveString += typed;
                    seed += typed;
                    renderNewGameMenu();
                }
            }
        }
    }

    private static void loadGame() {
        char[] saveChars = saveString.toCharArray();

        int i = 0;

        if (saveChars[i] == 'a' || saveChars[i] == 'A') {
            i++;
            avatarName = "";
            while (saveChars[i] != ':') {
                avatarName += saveChars[i];
                i++;
            }
            i++;
        }
        if (saveChars[i] == 'n' || saveChars[i] == 'N') {
            i++;
            while (i < saveChars.length && Character.isDigit(saveChars[i])) {
                seed += saveChars[i];
                i++;
            }
            generateWorld();
            i++;
            while (i < saveChars.length) {
                world.tryMoveAvatar(saveChars[i]);
                i++;
            }
            gamestate = 3;
        } else {
            throw new RuntimeException("sumin's wrong");
        }
    }

    private static void playGame() {
        if (StdDraw.hasNextKeyTyped()) {
            char typed = StdDraw.nextKeyTyped();
            while (typed == ':') {
                if (StdDraw.hasNextKeyTyped()) {
                    typed = StdDraw.nextKeyTyped();
                    if (typed == 'q') {
                        try {
                            writeToSave(saveString);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                        quitGame();
                    } else if (typed == 'l') {
                        losOn = !losOn;
                    } else {
                        break;
                    }
                }
            }
            saveString += typed;
            world.tryMoveAvatar(typed);
            renderGame(mouseX, mouseY);
        }
        int x = (int) StdDraw.mouseX();
        int y = (int) StdDraw.mouseY();
        if (x != mouseX || y != mouseY) {
            renderGame(x, y);
            mouseX = x;
            mouseY = y;
        }
    }

    private static void renderMainMenu() {
        StdDraw.clear();
        StdDraw.text(0.5, 0.8, "Main Menu");
        StdDraw.text(0.5, 0.6, "New Game (N)");
        StdDraw.text(0.5, 0.5, "Load Game (L)");
        StdDraw.text(0.5, 0.4, "Quit (Q)");
    }

    private static void renderNewGameMenu() {
        StdDraw.clear();
        StdDraw.text(0.5, 0.5, "Enter a seed: " + seed);
    }

    // TEMPORARY SOLUTION -- THIS NEEDS TO BE CHANGED -- SEE SPEC UNDER SKELETON CODE
    private static void quitGame() {
        System.exit(0);
    }

    // Render game now ONLY renders the game
    public static void renderWorld() {
        if (losOn) {
            ter.renderFrame(worldToLOS());
        } else {
            ter.renderFrame(world.mapToTile());
        }
    }

    public static void writeToSave(String saveInput) throws IOException {
        Files.write(save, saveInput.getBytes());
    }

    public static void renderGame(int x, int y) {

        TETile[][] tileArray;
        boolean inLOS;

        if (losOn) {
            tileArray = worldToLOS();
            inLOS = false;
        } else {
            tileArray = world.mapToTile();
            inLOS = true;
        }

        StdDraw.enableDoubleBuffering();
        StdDraw.clear();
        renderWorld();




        for (int a = x - 4; a <= x + 4; a++) {
            for (int b = y - 4; b <= y + 4; b++) {
                if (a < 80 && a >= 0 && b < 40 && b >= 0) {
                    if (tileArray[a][b] == Tileset.AVATAR) {
                        inLOS = true;
                    }
                }
            }
        }


        if (x < 80 && x >= 0 && y < 40 && y >= 0) {
            if (inLOS) {
                if (tileArray[x][y] == Tileset.NOTHING) {
                    renderHUD("nothing");
                } else if (tileArray[x][y] == Tileset.WALL) {
                    renderHUD("wall");
                } else if (tileArray[x][y] == Tileset.FLOOR) {
                    renderHUD("floor");
                } else if (tileArray[x][y] == Tileset.AVATAR) {
                    renderHUD(avatarName);
                }
            } else {
                renderHUD("unseen");
            }
        } else if (y >= 40) {
            renderHUD("OOB");
        }
    }

    public static void renderHUD(String message) {
        StdDraw.setPenColor(255, 255, 255);
        StdDraw.text(5, 41, message);
        StdDraw.text(20, 41, "The adventure of " + avatarName);
        StdDraw.show();
        StdDraw.pause(0);

    }

    public static TETile[][] worldToLOS() {
        TETile[][] returnArray = new TETile[world.getWIDTH()][world.getHEIGHT()];
        for (int i = 0; i < world.getWIDTH(); i++) {
            for (int j = 0; j < world.getHEIGHT(); j++) {
                returnArray[i][j] = Tileset.NOTHING;
            }
        }

        TETile[][] worldToTile = world.mapToTile();
        for (int i = 0; i < world.getWIDTH(); i++) {
            for (int j = 0; j < world.getHEIGHT(); j++) {
                if (worldToTile[i][j] == Tileset.AVATAR) {


                    for (int a = i - 4; a <= i + 4; a++) {
                        for (int b = j - 4; b <= j + 4; b++) {
                            if (a >= 0 && a < world.getWIDTH() && b >= 0 && b < world.getHEIGHT()) {
                                returnArray[a][b] = worldToTile[a][b];
                            }
                        }
                    }
                }
            }
        }
        return returnArray;
    }

    public static void renderAvatarMenu() {
        saveString += "A";

        avatarHelper();

        while (true) {
            if (StdDraw.hasNextKeyTyped()) {
                char typed = StdDraw.nextKeyTyped();

                if (typed == ':') {
                    if (!avatarName.isEmpty()) {
                        saveString += ':';
                        break;
                    }
                } else {
                    avatarName += typed;
                    saveString += typed;
                    avatarHelper();
                }
            }
        }
    }

    public static void avatarHelper() {
        StdDraw.enableDoubleBuffering();
        StdDraw.clear();
        StdDraw.text(0.5, 0.6, "This is the adventure of... ");
        StdDraw.text(0.5, 0.5, avatarName);
        StdDraw.text(0.5, 0.4, "(press : when finshed)");
        StdDraw.show();
    }
}
