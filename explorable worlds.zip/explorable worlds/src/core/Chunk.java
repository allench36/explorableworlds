package core;

import java.util.ArrayList;
import java.util.Random;

/**
 * Represents a fixed nxn portion of the array. Rooms of random size are generated inside
 * of this chunk.
 */
public class Chunk implements Comparable {
    Random random; // random object passed from main
    private final int[][] backing;
    private final int chunkSize;
    private final int roomWidth;
    private final int roomHeight;
    private final int order;
    private final ArrayList<int[]> floorCoords;

    public Chunk(int chunkSize, Random random, int order) {
        this.random = random;
        backing = new int[chunkSize][chunkSize];
        this.chunkSize = chunkSize;
        roomWidth = this.random.nextInt(4, chunkSize + 1);
        roomHeight = this.random.nextInt(4, chunkSize + 1);
        this.order = order;
        floorCoords = new ArrayList<>();

        makeRoom();
    }

    /**
     * Room generation begins at a random point inside the chunk.
     */
    public void makeRoom() {
        int startX = random.nextInt(0, chunkSize - roomWidth + 1);
        int startY = random.nextInt(0, chunkSize - roomHeight + 1);

        for (int i = startX + 1; i < startX + roomWidth; i++) {
            for (int j = startY + 1; j < startY + roomHeight; j++) {
                backing[i][j] = 1;
            }
        }
        for (int i = startX; i < startX + roomWidth; i++) {
            backing[i][startY + roomHeight - 1] = 2; // top wall
            backing[i][startY] = 2; // bottom wall
        }
        for (int i = startY; i < startY + roomHeight; i++) {
            backing[startX][i] = 2; // left wall
            backing[startX + roomWidth - 1][i] = 2; // right wall
        }
    }

    public void addFloorCoord(int a, int b) {
        int[] coords = new int[2];
        coords[0] = a;
        coords[1] = b;
        this.floorCoords.add(coords);
    }

    public int[][] getBacking() {
        return backing;
    }

    public int[] getRandomFloorCoords() {
        return floorCoords.get(random.nextInt(floorCoords.size()));
    }

    @Override
    public int compareTo(Object o) {
        if (o instanceof Chunk c) {
            return Integer.compare(this.order, c.order);
        }
        return 0;
    }

    public int getOrder() {
        return order;
    }
}
