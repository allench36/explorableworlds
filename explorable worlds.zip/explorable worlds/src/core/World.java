package core;

import edu.princeton.cs.algs4.UF; // for checking connectivity of world
import tileengine.TETile;
import tileengine.Tileset;

import java.util.*;

/**
 * Represents the entire world. Contains backing array that will be converted
 * to final tile array.
 */

/**
 * Changes:
 *
 * Reduced verbosity for easier extensibility/debugging.
 *
 * Moved all character movement and data to World class.
 *
 * Tweaked world generation. Before, world generation happened partially in myWorld and partially
 * in mapToTile().
 * Now, myWorld fully represents the world as integers. mapToTile() ONLY returns a tile array
 * that is exactly representative of the backing array.
 * The integer 3 represents the avatar in myWorld.
 */
public class World {
    private final int WIDTH = 80;
    private final int HEIGHT = 40;
    private final int CHUNK_SIZE = 10;
    private final int[][] myWorld; // integer array representation of world
    private TETile[][] finalWorld; // tile array representation of world
    private final Random random;
    private final Chunk[][] chunkArray; // chunk array representation of world
    private int chunkCount = 0;
    private final UF chunkUnion;
    private int[] avatarCoordinates; // current coordinates of the avatar

    public World(Random random) {
        myWorld = new int[WIDTH][HEIGHT];
        this.random = random;
        chunkArray = new Chunk[WIDTH / CHUNK_SIZE][HEIGHT / CHUNK_SIZE];

        generateChunks();

        chunkUnion = new UF(chunkCount);

        connectAllRooms();

        spawnAvatar();
    }

    /**
     * Create tile array for world
     */
    public TETile[][] mapToTile() {
        finalWorld = new TETile[WIDTH][HEIGHT];

        for (int i = 0; i < myWorld.length; i++) {
            for (int j = 0; j < myWorld[0].length; j++) {
                if (myWorld[i][j] == 0) {
                    finalWorld[i][j] = Tileset.NOTHING;
                } else if (myWorld[i][j] == 1) {
                    finalWorld[i][j] = Tileset.FLOOR;
                } else if (myWorld[i][j] == 2) {
                    finalWorld[i][j] = Tileset.WALL;
                } else if (myWorld[i][j] == 3) {
                    finalWorld[i][j] = Tileset.AVATAR;
                }
            }
        }

        return finalWorld;
    }

    private void hallwayWalls(int i, int j) {
        for (int a = i - 1; a <= i + 1; a++) {
            for (int b = j - 1; b <= j + 1; b++) {
                if (myWorld[a][b] == 0) {
                    myWorld[a][b] = 2;
                }
            }
        }
    }

    /**
     * Grabs random floor tile coordinate from array containing all floor tile coordinates and spawns
     * avatar at that coordinate (only done when the world is first created)
     */
    private void spawnAvatar() {

        avatarCoordinates = new int[2];

        int i = 0;
        int j = 0;

        while (myWorld[i][j] != 1) {
            i = random.nextInt(0, WIDTH);
            j = random.nextInt(0, HEIGHT);
        }

        avatarCoordinates[0] = i;
        avatarCoordinates[1] = j;
        myWorld[avatarCoordinates[0]][avatarCoordinates[1]] = 3;
    }

    /**
     * Moves the avatar to its new spot and updates its coordinates
     * @param dir: "direction" refers to W/A/S/D the user inputted
     */
    public void tryMoveAvatar(char dir) {
        int x = avatarCoordinates[0];
        int y = avatarCoordinates[1];
        if (dir == 'w' || dir == 'W') {
            if (this.myWorld[x][y + 1] == 1) {
                myWorld[x][y] = 1;
                myWorld[x][y + 1] = 3;
                avatarCoordinates[1] = y + 1;
            }
        } else if (dir == 'a' || dir == 'A') {
            if (this.myWorld[x - 1][y] == 1) {
                myWorld[x][y] = 1;
                myWorld[x - 1][y] = 3;
                avatarCoordinates[0] = x - 1;
            }
        } else if (dir == 's' || dir == 'S') {
            if (this.myWorld[x][y - 1] == 1) {
                myWorld[x][y] = 1;
                myWorld[x][y - 1] = 3;
                avatarCoordinates[1] = y - 1;
            }
        } else if (dir == 'd' || dir == 'D') {
            if (this.myWorld[x + 1][y] == 1) {
                myWorld[x][y] = 1;
                myWorld[x + 1][y] = 3;
                avatarCoordinates[0] = x + 1;
            }
        }
    }

    /**
     * Generates chunks in the world backing array. 1/4 chance that a chunk is empty.
     */
    private void generateChunks() {
        int order = 0;
        for (int i = 0; i < WIDTH; i += CHUNK_SIZE) {
            for (int j = 0; j < HEIGHT; j += CHUNK_SIZE) {
                if (random.nextInt(4) != 0) {
                    Chunk chunk = new Chunk(CHUNK_SIZE, random, order);
                    order += 1;
                    chunkCount++;
                    chunkArray[i / CHUNK_SIZE][j / CHUNK_SIZE] = chunk;
                    for (int a = 0; a < CHUNK_SIZE; a++) {
                        for (int b = 0; b < CHUNK_SIZE; b++) {
                            myWorld[i + a][j + b] = chunk.getBacking()[a][b];

                            if (chunk.getBacking()[a][b] == 1) {
                                chunk.addFloorCoord(i + a, j + b);

                            }
                        }
                    }
                }
            }
        }
    }

    private void connectAllRooms() {
        for (int i = 0; i < WIDTH / CHUNK_SIZE; i++) {
            for (int j = 0; j < HEIGHT / CHUNK_SIZE; j++) {
                if (chunkArray[i][j] != null) {
                    List<Chunk> neighbors = findNearestNeighbors(i, j);

                    Chunk chunkA = chunkArray[i][j];

                    Chunk chunkB = neighbors.get(random.nextInt(neighbors.size()));

                    connectRooms(chunkA.getRandomFloorCoords(), chunkB.getRandomFloorCoords());

                    chunkUnion.union(chunkA.getOrder(), chunkB.getOrder());

                }
            }
        }
        TreeSet<Integer> roots = new TreeSet<>();

        for (int i = 0; i < chunkCount; i++) {
            roots.add(chunkUnion.find(i));
        }

        Iterator<Integer> rootsIter = roots.iterator();

        Chunk chunkA = getChunkByOrder(rootsIter.next());

        while (rootsIter.hasNext()) {
            Chunk chunkB = getChunkByOrder(rootsIter.next());
            connectRooms(chunkA.getRandomFloorCoords(), chunkB.getRandomFloorCoords());
            chunkUnion.union(chunkA.getOrder(), chunkB.getOrder());
            chunkA = chunkB;
        }

        for (int i = 0; i < myWorld.length; i++) {
            for (int j = 0; j < myWorld[0].length; j++) {
                if (myWorld[i][j] == 1) {
                    hallwayWalls(i, j);
                }
            }
        }


    }

    private Chunk getChunkByOrder(int order) {
        for (int i = 0; i < WIDTH / CHUNK_SIZE; i++) {
            for (int j = 0; j < HEIGHT / CHUNK_SIZE; j++) {
                if (chunkArray[i][j] != null && chunkArray[i][j].getOrder() == order) {
                    return chunkArray[i][j];
                }
            }
        }
        return null;
    }

    private List<Chunk> findNearestNeighbors(int i, int j) {
        List<Chunk> returnList = new ArrayList<>();

        int xstart = i - 1;
        int xend = i + 1;
        int ystart = j - 1;
        int yend = j + 1;

        while (returnList.isEmpty()) {
            for (int a = xstart; a <= xend; a++) {
                for (int b = ystart; b <= yend; b++) {
                    if ((a != i || b != j)
                            && (a >= 0 && b >= 0)
                            && (a < WIDTH / CHUNK_SIZE && b < HEIGHT / CHUNK_SIZE)) {
                        Chunk neighborChunk = chunkArray[a][b];
                        if (neighborChunk != null) {
                            returnList.add(neighborChunk);
                        }
                    }
                }
            }
            xstart--;
            xend++;
            ystart--;
            yend++;
        }

        return returnList;
    }

    private void connectRooms(int[] start, int[] end) {
        int startX = start[0];
        int startY = start[1];
        int endX = end[0];
        int endY = end[1];

        if (startX > endX) {
            for (int i = startX; i > endX; i--) {
                myWorld[i][startY] = 1;
            }
        } else {
            for (int i = startX; i < endX; i++) {
                myWorld[i][startY] = 1;
            }
        }
        if (startY > endY) {
            for (int i = startY; i > endY; i--) {
                myWorld[endX][i] = 1;
            }
        } else {
            for (int i = startY; i < endY; i++) {
                myWorld[endX][i] = 1;
            }
        }
    }

    public boolean fullyConnected() {
        TreeSet<Integer> roots = new TreeSet<>();

        for (int i = 0; i < chunkCount; i++) {
            roots.add(chunkUnion.find(i));
        }

        return roots.size() == 1;
    }

    public int getWIDTH() {
        return WIDTH;
    }

    public int getHEIGHT() {
        return HEIGHT;
    }
}
