import core.World;
import edu.princeton.cs.algs4.StdDraw;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TestConnectivity {
    @Test
    public void testConnectivity() {
        for (int i = 10000; i < 11000; i++) {
            Random random = new Random(i);
            World newWorld = new World(random);
            if (!newWorld.fullyConnected()) {
                System.out.println(i);
            }
        }
    }
}
