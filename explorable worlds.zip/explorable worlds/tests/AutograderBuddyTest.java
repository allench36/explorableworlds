import core.AutograderBuddy;
import org.junit.jupiter.api.Test;
import tileengine.TERenderer;
import tileengine.TETile;

import java.io.IOException;

public class AutograderBuddyTest {

    @Test
    public void testAutograderBuddy() throws IOException {
        TERenderer ter = new TERenderer();
        ter.initialize(80, 40);
        ter.renderFrame(AutograderBuddy.getWorldFromInput("N123AAAAAAAAAAAAA"));
    }
}
